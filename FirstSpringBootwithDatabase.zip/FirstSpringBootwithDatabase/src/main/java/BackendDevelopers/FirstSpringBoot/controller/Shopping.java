package BackendDevelopers.FirstSpringBoot.controller;
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import BackendDevelopers.FirstSpringBoot.model.Product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;

//@RequestController converts a normal java class into a controller 
//A Controller has one or more API'S
@RestController
@RequestMapping("/Shopping")
public class Shopping {
	public long visitorCount=0;
	
	/*Creates an object for ProductService class automatically. so, that becomes a bean That bean 
	 * is injected into the controller(Shopping). this is an example of dependency
	 * injection mechanism. Autowiring is a type of dependency injection mechanism.
	 */
	
	@Autowired 
	ProductService service;
	public Shopping() {
		System.err.println("Shopping controller created..");
	}
	
	//link this API with browser
	//if the request type is GET and the URL is http://localhost:9080/Shopping/, then call home() method and return response to the client.
	@RequestMapping(path = "/", method=RequestMethod.GET)
	// call back method
	public String home() {
		//preparing the response and sends it to the client
		visitorCount++;
		String response="<html><body><h1>";
		response += "Welcome to online shopping</h1><br>";
		response +="<b>You are visitor #</b>" + visitorCount;
		response +="</body></html>";
		return response;
		
		
	}
	//used to handle GET mapping. if url ends with /list and the request type is GET,
	//Then getProductsList() method returns the list of products to the client. 
	@GetMapping(path="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ArrayList<Product> getProductsList() {
		System.out.println("Got the request.....");		
		return service.getProductList();
		
	}
	
	//@RequestPara indicates that type value for products is sent at the end of url
	@GetMapping("/search")// search is api that short name of url. when data is sent in the url as a key value pair,
	/*@PathParam is used to retrieve the data using the key. retrieve data is stored into productId.
	 If the request type is GET and the url is as follows:
	 http://localhost:9080/Shopping/search?pId=4
	//@RequestParam is used in the API to retrieve the value of pId and store it into productId */
	public String searchProduct(@RequestParam("pId") int productId) {  
		// searchProduct is api's actual name
		return service.searchById(productId);
		
	}
	
	//@RequestBody is used to handle http DELETE request. if DELETE request is sent, 
	 //then deleteProduct() method is called the delete the product
	// @RequestBody is used when the client sends data from a HTML form using either POST request or PUT request or DELETE request
	// or update request RequestBody contains the data sent by the client
	@DeleteMapping(path="/deleteId/{pId}")
	public String deleteProduct(@PathVariable("pId") int productId) {
		System.out.println("Got a request...");
		return service.deleteProduct(productId);
		
		}
	
	/*@PostMapping is used receive POST request from the client. 
	 * if the url ends with /add and request type is POST, then addProduct() method called to add a new product to the HashMap
	 * when POST request is issued by the client, data is sent inside the client request packet.
	 * so to read the data, use @RequestBody annotation. all the data sent through post request must be stored in an object only
	 * so, we have to define a POJO class called Product.
	 * consumes attributes makes the server to accept data in specific formats only.
	 * the client has to send the data in the format declared by the server.
	 * 
	 * Dependency injection is followed. the object p for product class is automatically created
	 * and managed by Springboot framework. so, p is a managed object or also called java bean.
	*/
	@PostMapping(path="/add", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String addProduct(@RequestBody Product p) {
		System.out.println("Got a post Request......");
		return service.addProduct(p);
		
	}
	@PutMapping(path="/update", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody Product p) {
		System.out.println("Got a put Request......");
		return service.updateProduct(p.getProductId(), p.getProductName());
		
		
	}
}