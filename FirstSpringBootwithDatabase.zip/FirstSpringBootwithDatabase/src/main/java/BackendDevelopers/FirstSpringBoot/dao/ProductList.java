package BackendDevelopers.FirstSpringBoot.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import BackendDevelopers.FirstSpringBoot.model.Product;

@Repository
// convert this class into interface to connecting this to database
public interface ProductList extends CrudRepository<Product, Integer>{
	/*CrudRepository<Product, Integer>
	 * Product is the data that will inserted into the database or retrieved from the database.
	 * Integer is the database of the primary key.
	 */
	
	
	
	
	}
