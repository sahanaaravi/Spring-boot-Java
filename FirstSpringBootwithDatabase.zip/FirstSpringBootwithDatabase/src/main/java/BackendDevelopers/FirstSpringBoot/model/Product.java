package BackendDevelopers.FirstSpringBoot.model;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.*;

 
//Linking this POJO class to the table in the database.
@Entity
@Table(name= "Product")
public class Product {
	@Id // in the database this column is a primary key for generating primary key automatically
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int productId;
	
	//Link productName variable with productName column in the database
	@Column(name= "productName")
	private String productName;
	
	public Product() {
		super();
		System.out.println("New Product Created....");
	}
	
	public Product(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
		System.out.println("New Product Created with productId and ProductName....");
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
		System.out.println("Stored productId......");
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
		System.out.println("Stored productName.....");
	}
	
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + "]" + " - " + hashCode();
	}
	
}
