package BackendDevelopers.FirstSpringBoot.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import BackendDevelopers.FirstSpringBoot.dao.ProductList;
import BackendDevelopers.FirstSpringBoot.model.Product;
/*Any class marked with @Service controls concurrent or parallel access to the DAO layer, there by 
 * preventing data loss or data ambiguity or data corruption.
*@Service automatically create the bean for ProductService
*/
@Service
public class ProductService {
	//Manually injecting the productList Object into the service.
	@Autowired
	ProductList plist;
	public ArrayList<Product> getProductList(){
		System.out.println("Getting products List...");
		//When you call findAll() method in the repository, it
		//executes the SQL SELECT  * from Products statement on the database.
		return (ArrayList<Product>)plist.findAll();
		}
	public String addProduct(Product p) {
		System.out.println("In service Adding product...");
		Product t=plist.save(p);    // save means convert this into SQL INSERT  statement
		return "<b>Added or inserted the product</b> "+ t;
		}
	public String deleteProduct(int productId){
		System.out.println("In service. Deleting product....");
		//For example: if ProductId is 3,
		//When deleteById() is called, it convert this into 
		// SQL DELETE from Product where productId=3
		plist.deleteById(productId);
		return "<B>Deleted product with Id </b>" + productId;
		}
	public String searchById(int productId) {
		System.out.println("In service searching by Id...");
		//If productId is 4, this is converted to SQL 
		//SELECT * FROM PRODUCT where ProductId=4
		Optional<Product> opt=plist.findById(productId);
		return "Located Product " + opt.get().toString();
		}
	public String updateProduct(int productId, String newProductName) {
		System.out.println("In service updating product...");
		Product d=new Product(productId, newProductName);
		//When save() is called, if any product with given productId is existing,
		// it inserts a new record
		return "Updated with" + plist.save(d).toString();
}

}
