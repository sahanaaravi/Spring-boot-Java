package BackendDevelopers.FirstSpringBoot.controller;
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import BackendDevelopers.FirstSpringBoot.model.Product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;

//@RequestController converts a normal java class into a controller 
//A Controller has one or more API'S
@Controller
//@RestController
@RequestMapping("/Shopping")
public class Shopping {
	public long visitorCount=0;
	
	/*Creates an object for ProductService class automatically. so, that becomes a bean That bean 
	 * is injected into the controller(Shopping). this is an example of dependency
	 * injection mechanism. Autowiring is a type of dependency injection mechanism.
	 */
	
	@Autowired 
	ProductService service;
	public Shopping() {
		System.err.println("Shopping controller created..");
	}
	
	//link this API with browser
	//if the request type is GET and the URL is http://localhost:9080/Shopping/, then call home() method and return response to the client.
	@RequestMapping(path = "/", method=RequestMethod.GET)
	// call back method
	public ModelAndView home() {
		//preparing the response and sends it to the client
		visitorCount++;
		ModelAndView mv=new ModelAndView();
		mv.setViewName("home");// Name of the HTML file
		mv.addObject("visCount", visitorCount);
		return mv;
		}
	//used to handle GET mapping. if url ends with /list and the request type is GET,
	//Then getProductsList() method returns the list of products to the client. 
	@GetMapping(path="/list")
	public ModelAndView getProductList() {
		ModelAndView mv=new ModelAndView();
		//Mention the name of the view (HTML files) to be displayed
		mv.setViewName("listProduct");
		//Attaching(binding) the model(data) with the view.
		mv.addObject("products", service.getProductList());
		return mv; //Sending the response
		}
	
	//@RequestPara indicates that type value for products is sent at the end of url
	@GetMapping("/search")// search is api that short name of url. when data is sent in the url as a key value pair,
	/*@PathParam is used to retrieve the data using the key. retrieve data is stored into productId.
	 If the request type is GET and the url is as follows:
	 http://localhost:9080/Shopping/search?pId=4
	//@RequestParam is used in the API to retrieve the value of pId and store it into productId */
	public String searchProduct(@RequestParam("pId") int productId) {  
		// searchProduct is api's actual name
		return service.searchById(productId);
		
	}
	
	@GetMapping("/delete")
	public ModelAndView deleteP() {
	    ModelAndView mv = new ModelAndView();
	    mv.setViewName("deleteProduct"); // confirmation view
	    mv.addObject("Today", new java.util.Date().toString());
	    mv.addObject("products", service.getProductList());
	    return mv;
	}
	@PostMapping("/deleteProduct")
	public ModelAndView deleteProduct(@RequestParam("productId") int productId) {
	    String result = service.deleteProduct(productId);
	    ModelAndView mv = new ModelAndView("deletedproduct");
	    mv.addObject("message", result);
	    mv.addObject("Today", new java.util.Date().toString());
	    return mv;
	}


	@GetMapping("/add")
	public ModelAndView addP() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("addProduct");
		mv.addObject("Today", new java.util.Date().toString());
		visitorCount++;
		mv.addObject("vCount", visitorCount);
		return mv;
	}
	@PostMapping(path="/addProduct")
	public ModelAndView addProduct(@ModelAttribute Product p) {
		ModelAndView mv=new ModelAndView();
		Product t=service.addProduct(p);
		//Name of the view(HTML page) that has shown in the browser
		mv.setViewName("addedProduct");
		mv.addObject("Product",t);
		return mv;
		}
	
	// ✅ Show Update Page (Form)
	 @GetMapping("/update")
	    public ModelAndView updateP() {
	        ModelAndView mv = new ModelAndView();
	        mv.setViewName("updateProduct"); // JSP/HTML form page name
	        mv.addObject("products", service.getProductList()); // Optional, if needed
	        return mv;
	    }


	 @PostMapping("/updateProduct")
	    public ModelAndView processUpdate(@RequestParam("pId") int productId,
	                                      @RequestParam("newName") String productName) {
	        ModelAndView mv = new ModelAndView();
	        service.updateProduct(productId, productName);
	        mv.setViewName("updatedProduct"); // ✅ Correct view to render after update
	        return mv;
	    }
}