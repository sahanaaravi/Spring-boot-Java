package LocationFaultService.LocationFaultService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Bikes")
public class StoreInfoController {

	/*This contains the routing and ping logic.
	 * This has to be Autowired.
	 * Any Hystrix application will have customized routing logic.*/
	@Autowired
	TestLocationService  locService;
	
	@RequestMapping(value="/storeInfo", method=RequestMethod.GET)
	public String getStoreInfo() {
		return locService.getStoreInfo();
	}
}
