package LocationFaultService.LocationFaultService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

//The class containing the routing/false-tolerance logic must be marked as a service
@Service
public class TestLocationService {
	@Autowired
	RestTemplate  resttemp;
		
	//timeOutInMilliseconds means within that time, the instance @ port 9000 must respond.
	@HystrixCommand(fallbackMethod="pingAlternate_Fallback", commandProperties= 
		{@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="5000")})
	public  String getStoreInfo() {
		System.out.println("Trying to ping to localhost:9000");
		/*
		 * exchange(URL, RequestType, <parameters/null>, <ReturnType>)
		 */
		//if this call fails, then run the fallbackMethod
		String res=resttemp.exchange("http://localhost:9000/Bikes/info", 
				HttpMethod.GET,null, java.lang.String.class).getBody();
		System.out.println("Got the response from localhost:9000");
		return res;
	}
	//These methods are called fallbackMethod/callbackMethod. It is called 
	//automatically by Hystrix. Not explicitly.
	@HystrixCommand(fallbackMethod="mirror1_Fallback", commandProperties= 
		{@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="5000")})
	private String pingAlternate_Fallback()
	{
		System.out.println("Pinging to alternate @ 10000");
		String res=resttemp.exchange("http://localhost:10000/Bikes/info", 
				HttpMethod.GET,null, java.lang.String.class).getBody();
		System.out.println("Got the response");
		return res;
	}
	
	private String mirror1_Fallback() {
		System.out.println("Pinging to alternate @ 11000");
		String res=resttemp.exchange("http://localhost:11000/Bikes/info", 
				HttpMethod.GET,null, java.lang.String.class).getBody();
		System.out.println("Got the response");
		return res;
	}
	//Customizing the bean creation.
	@Bean
	public RestTemplate  resttemp() {
		return  new RestTemplate();
	}
}
