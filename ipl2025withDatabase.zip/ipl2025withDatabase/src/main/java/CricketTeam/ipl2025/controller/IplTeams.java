package CricketTeam.ipl2025.controller;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import CricketTeam.ipl2025.model.Teams;
import CricketTeam.ipl2025.service.TeamsService;
@RestController
@RequestMapping("/IplTeams")
public class IplTeams {
	public long visitorCount=0;
	
	@Autowired 
	TeamsService service;
	public IplTeams() {
		System.err.println("IplTeams controller created..");
	}
	@RequestMapping(path = "/", method=RequestMethod.GET)

	public String home() {
		visitorCount++;
		String response="<html><body><h1>";
		response += "Welcome to IPL Cricket</h1><br>";
		response +="<b>You are visitor #</b>" + visitorCount;
		response +="</body></html>";
		return response;
		}
	@GetMapping(path="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ArrayList<Teams> getTeamsList() {
		return service.getTeamsList();
		}
	@GetMapping("/search")
	public String searchTeams(@RequestParam("pId") int teamsId) {  
		return service.searchById(teamsId);
		}
	@DeleteMapping(path="/deleteId/{pId}")
	public String deleteTeams(@PathVariable("pId") int teamsId) {
		System.out.println("Got a request...");
		return service.deleteTeams(teamsId);
		
		}
	 @PostMapping(path="/add", consumes=MediaType.APPLICATION_JSON_VALUE)
	    public String addTeams(@RequestBody Teams p) {
	        System.out.println("Got a POST request...");
	        return service.addTeams(p);
	    }
	@PutMapping(path="/update", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateTeams(@RequestBody Teams p) {
		System.out.println("Got a put Request......");
		return service.updateTeams(p.getTeamsId(), p.getTeamsName());
		}
}