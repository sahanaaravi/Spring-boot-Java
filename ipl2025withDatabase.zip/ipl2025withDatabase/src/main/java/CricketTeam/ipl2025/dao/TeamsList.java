package CricketTeam.ipl2025.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import CricketTeam.ipl2025.model.Teams;

@Repository
// convert this class into interface to connecting this to database
public interface TeamsList extends CrudRepository<Teams, Integer>{
	
	
	}