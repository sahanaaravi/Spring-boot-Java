package CricketTeam.ipl2025.model;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.*;

@Entity
@Table(name= "Teams")
public class Teams {
	@Id 
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int teamsId;
	@Column(name= "teamsName")
	private String teamsName;
	
	public Teams() {
		super();
		System.out.println("Teams entity Created....");
	}
	
	public Teams(int teamsId, String teamsName) {
		super();
		this.teamsId = teamsId;
		this.teamsName = teamsName;
		System.out.println("Teams Created with teamsId and teamsName....");
	}
	public int getTeamsId() {
		return teamsId;
	}
	public void setTeamsId(int teamsId) {
		this.teamsId = teamsId;
		System.out.println("Stored teamsId......" + teamsId);
	}
	public String getTeamsName() {
		return teamsName;
	}
	public void setTeamsName(String teamsName) {
		this.teamsName = teamsName;
		System.out.println("Stored teamsName....." + teamsName );
	}
	
	@Override
	public String toString() {
		return "Teams [teamsId=" + teamsId + ", teamsName=" + teamsName + "]" + " - " + hashCode();
	}
	
}
