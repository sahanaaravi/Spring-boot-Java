package CricketTeam.ipl2025.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import CricketTeam.ipl2025.dao.TeamsList;
import CricketTeam.ipl2025.model.Teams;

@Service
public class TeamsService {
	@Autowired
	TeamsList plist;
	public ArrayList<Teams> getTeamsList(){
		System.out.println("Getting teams List...");
		return (ArrayList<Teams>)plist.findAll();
		}
	public String addTeams(Teams p) {
		System.out.println("In service Adding teams...");
		Teams t=plist.save(p);    // save means convert this into SQL INSERT  statement
		return "<b>Added or inserted the teams</b> "+ t;
		}
	public String deleteTeams(int teamsId){
		System.out.println("In service. Deleting teams....");
		plist.deleteById(teamsId);
		return "<B>Deleted teams with Id </b>" + teamsId;
		}
	public String searchById(int teamsId) {
		System.out.println("In service searching by Id...");
		Optional<Teams> opt=plist.findById(teamsId);
		return "Located teams " + opt.get().toString();
		}
	public String updateTeams(int teamsId, String newTeamsName) {
		System.out.println("In service updating teams...");
		Teams d=new Teams(teamsId, newTeamsName);
		return "Updated with" + plist.save(d).toString();
}}
