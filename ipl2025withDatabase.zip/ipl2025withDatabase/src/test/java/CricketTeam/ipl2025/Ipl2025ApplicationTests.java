package CricketTeam.ipl2025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ipl2025ApplicationTests {

	@Test
	void contextLoads() {
	}

}
